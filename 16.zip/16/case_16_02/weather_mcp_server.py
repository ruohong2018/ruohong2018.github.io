from mcp.server.fastmcp import FastMCP
from datetime import datetime

mcp = FastMCP("天气查询服务器")

# 模拟天气数据（实际项目中替换为真实的天气 API 调用）
WEATHER_DB = {
    "北京": {"temp": 26, "weather": "晴", "humidity": 45, "wind": "北风3级"},
    "上海": {"temp": 28, "weather": "多云", "humidity": 65, "wind": "东风2级"},
    "广州": {"temp": 31, "weather": "雷阵雨", "humidity": 80, "wind": "南风3级"},
    "深圳": {"temp": 30, "weather": "晴", "humidity": 55, "wind": "东南风2级"},
    "成都": {"temp": 24, "weather": "阴", "humidity": 70, "wind": "北风1级"},
}


@mcp.tool()
def get_weather(city: str) -> str:
    """查询指定城市的天气信息

    Args:
        city: 城市名称，如"北京"、"上海"
    """
    if city not in WEATHER_DB:
        available = "、".join(WEATHER_DB.keys())
        return f"抱歉，暂不支持查询 {city} 的天气。目前支持的城市有：{available}"

    data = WEATHER_DB[city]
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    report = f"""【{city}】天气报告
================
时间: {now}
天气: {data['weather']}
温度: {data['temp']}°C
湿度: {data['humidity']}%
风速: {data['wind']}"""
    return report


@mcp.tool()
def get_forecast(city: str, days: int = 3) -> str:
    """查询指定城市未来几天的天气预报

    Args:
        city: 城市名称
        days: 预报天数，1-7 之间
    """
    if city not in WEATHER_DB:
        return f"抱歉，暂不支持查询 {city}"

    days = min(max(days, 1), 7)

    forecasts = {
        "北京": ["晴 26°C", "多云 25°C", "小雨 23°C", "晴 27°C", "晴 28°C"],
        "上海": ["多云 28°C", "阴 26°C", "小雨 25°C", "多云 27°C", "晴 29°C"],
        "广州": ["雷阵雨 31°C", "大雨 29°C", "多云 30°C", "晴 32°C", "雷阵雨 30°C"],
        "深圳": ["晴 30°C", "多云 29°C", "阴 28°C", "晴 30°C", "多云 31°C"],
        "成都": ["阴 24°C", "小雨 22°C", "阴 23°C", "多云 25°C", "晴 26°C"],
    }

    lines = [f"【{city}】未来{days}天预报"]
    lines.append("-" * 25)
    for i, fc in enumerate(forecasts.get(city, [])[:days], 1):
        lines.append(f"第{i}天: {fc}")

    return "\n".join(lines)


@mcp.resource("weather://realtime/{city}")
def realtime_weather(city: str) -> str:
    """返回城市的实时天气数据（JSON 格式，供 Agent 程序化使用）"""
    import json

    if city not in WEATHER_DB:
        return json.dumps({"error": f"城市 {city} 不支持"})
    data = WEATHER_DB[city].copy()
    data["city"] = city
    data["timestamp"] = datetime.now().isoformat()
    return json.dumps(data, ensure_ascii=False)


if __name__ == "__main__":
    mcp.run()
