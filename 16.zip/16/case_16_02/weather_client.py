import asyncio
from mcp import ClientSession, StdioServerParameters, stdio_client


async def main():
    params = StdioServerParameters(
        command="python",
        args=["src/case_16_02/weather_mcp_server.py"],
        cwd="/Users/dingying/Desktop/tmp1",
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            print("=" * 40)
            print("天气查询系统 - MCP 客户端")
            print("=" * 40)

            # 调用工具：查询北京天气
            print("\n[查询] 北京的天气")
            result = await session.call_tool("get_weather", {"city": "北京"})
            print(result.content[0].text)

            # 调用工具：查询广州的5天预报
            print("\n[查询] 广州未来5天预报")
            result = await session.call_tool(
                "get_forecast", {"city": "广州", "days": 5}
            )
            print(result.content[0].text)

            # 调用工具：查询不支持的城市
            print("\n[查询] 武汉的天气（不支持的城市）")
            result = await session.call_tool("get_weather", {"city": "武汉"})
            print(result.content[0].text)


if __name__ == "__main__":
    asyncio.run(main())
