from mcp.server.fastmcp import FastMCP

mcp = FastMCP("项目管理服务器")

tasks_db = [
    {"id": "1", "title": "设计架构图", "status": "done", "assignee": "张三"},
    {"id": "2", "title": "编写 API 文档", "status": "in_progress", "assignee": "李四"},
    {"id": "3", "title": "单元测试", "status": "pending", "assignee": "王五"},
]


@mcp.tool()
def create_task(title: str, assignee: str) -> str:
    """创建一个新任务

    Args:
        title: 任务标题
        assignee: 负责人
    """
    new_id = str(len(tasks_db) + 1)
    new_task = {
        "id": new_id,
        "title": title,
        "status": "pending",
        "assignee": assignee,
    }
    tasks_db.append(new_task)
    return f"任务已创建，ID: {new_id}，标题: {title}"


@mcp.tool()
def list_tasks(status_filter: str = None) -> str:
    """列出所有任务，支持按状态过滤

    Args:
        status_filter: 可选，按状态过滤 (pending/in_progress/done)
    """
    if status_filter:
        filtered = [t for t in tasks_db if t["status"] == status_filter]
    else:
        filtered = tasks_db

    if not filtered:
        return "没有找到符合条件的任务"

    lines = ["ID | 标题 | 状态 | 负责人"]
    lines.append("-" * 40)
    for task in filtered:
        lines.append(
            f"{task['id']} | {task['title']} | {task['status']} | {task['assignee']}"
        )
    return "\n".join(lines)


@mcp.tool()
def complete_task(task_id: str) -> str:
    """标记指定任务为完成

    Args:
        task_id: 任务 ID
    """
    for task in tasks_db:
        if task["id"] == task_id:
            task["status"] = "done"
            return f"任务 {task_id} 已标记为完成"
    return f"未找到 ID 为 {task_id} 的任务"


@mcp.resource("task://list")
def task_list_resource() -> str:
    """返回任务列表的 JSON 格式数据"""
    import json

    return json.dumps(tasks_db, ensure_ascii=False, indent=2)


@mcp.resource("stats://project")
def project_stats_resource() -> str:
    """返回项目统计数据"""
    total = len(tasks_db)
    done = sum(1 for t in tasks_db if t["status"] == "done")
    in_progress = sum(1 for t in tasks_db if t["status"] == "in_progress")
    pending = sum(1 for t in tasks_db if t["status"] == "pending")

    stats = f"""项目统计概览
============
总任务数: {total}
已完成: {done} ({done*100//total if total else 0}%)
进行中: {in_progress} ({in_progress*100//total if total else 0}%)
待处理: {pending} ({pending*100//total if total else 0}%)"""
    return stats


if __name__ == "__main__":
    mcp.run()
