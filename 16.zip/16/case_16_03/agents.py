from a2a_core import AgentCard, Task, TaskStatus, Skill
from a2a_network import AgentNetwork
import time


class TaskDispatcherAgent:
    """任务分发 Agent：接收用户请求，决定分发给哪个执行 Agent"""

    def __init__(self, network: AgentNetwork):
        self.network = network
        self.card = AgentCard(
            name="任务分发 Agent",
            description="接收用户请求，分析任务类型，分发给合适的执行 Agent",
            url="http://dispatcher:8001",
            version="1.0.0",
            skills=[
                Skill(
                    "task-analysis",
                    "任务分析",
                    "分析用户需求，确定任务类型和执行方案",
                ),
                Skill(
                    "agent-routing",
                    "智能路由",
                    "根据任务类型选择最合适的执行 Agent",
                ),
            ],
        )
        self.network.register(self.card)

    def handle_request(self, user_request: str) -> str:
        """处理用户请求"""
        print(f"\n{'='*50}")
        print(f"[分发 Agent] 收到请求: {user_request}")

        # 分析请求，决定路由
        if "天气" in user_request:
            target_skill = "weather-query"
            target_agent_name = "天气查询 Agent"
        elif "邮件" in user_request or "发送" in user_request:
            target_skill = "email-sending"
            target_agent_name = "邮件发送 Agent"
        elif "搜索" in user_request:
            target_skill = "web-search"
            target_agent_name = "网络搜索 Agent"
        else:
            return "抱歉，我无法理解这个请求的类型。"

        # 找到执行 Agent
        executor = self.network.find_agent(target_skill)
        if not executor:
            return f"错误：系统中没有找到支持 '{target_skill}' 技能的 Agent"

        # 创建任务并分发
        task = self.network.create_task(target_agent_name, user_request)
        task.update_status(TaskStatus.WORKING)
        self.network.route_message(
            task.id, "分发 Agent", f"请执行任务: {user_request}"
        )

        print(f"[分发 Agent] 任务 {task.id} 已分发给 {target_agent_name}")
        return f"已将请求转发给 {target_agent_name}（任务ID: {task.id}）"


class WeatherQueryAgent:
    """天气查询 Agent"""

    def __init__(self, network: AgentNetwork):
        self.network = network
        self.card = AgentCard(
            name="天气查询 Agent",
            description="提供全球主要城市的实时天气查询和预报服务",
            url="http://weather-agent:8002",
            version="1.0.0",
            skills=[
                Skill(
                    "weather-query",
                    "天气查询",
                    "查询全球主要城市的实时天气",
                ),
            ],
        )
        self.network.register(self.card)

    def execute_task(self, task: Task) -> str:
        """执行天气查询任务"""
        print(f"\n[天气 Agent] 开始执行任务 {task.id}")
        task.update_status(TaskStatus.WORKING)

        time.sleep(0.5)  # 模拟处理时间

        result = "查询结果：北京今日晴朗，气温26°C，适合出行。"
        task.update_status(TaskStatus.COMPLETED, result)
        return result
