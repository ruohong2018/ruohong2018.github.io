from dataclasses import dataclass, field
from typing import List, Dict, Any
from enum import Enum
import uuid


class TaskStatus(Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input_required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


@dataclass
class Skill:
    id: str
    name: str
    description: str


@dataclass
class AgentCard:
    name: str
    description: str
    url: str
    version: str
    skills: List[Skill] = field(default_factory=list)
    capabilities: Dict[str, bool] = field(
        default_factory=lambda: {
            "streaming": False,
            "pushNotifications": True,
        }
    )


@dataclass
class Task:
    id: str
    agent_name: str
    description: str
    status: TaskStatus = TaskStatus.SUBMITTED
    messages: List[Dict[str, str]] = field(default_factory=list)
    result: Any = None

    def __post_init__(self):
        self.id = self.id or str(uuid.uuid4())[:8]

    def add_message(self, sender: str, content: str):
        self.messages.append({"sender": sender, "content": content})

    def update_status(self, new_status: TaskStatus, result: Any = None):
        self.status = new_status
        if result is not None:
            self.result = result
        print(f"[任务 {self.id}] 状态更新: {new_status.value} | 结果: {result}")
