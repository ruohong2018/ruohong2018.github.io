from a2a_core import AgentCard, Task, TaskStatus, Skill
from typing import Dict, Optional


class AgentNetwork:
    """A2A 网络的核心：Agent 注册表和消息路由器"""

    def __init__(self):
        self.agents: Dict[str, AgentCard] = {}
        self.tasks: Dict[str, Task] = {}

    def register(self, agent_card: AgentCard):
        """Agent 注册到网络"""
        self.agents[agent_card.name] = agent_card
        print(f"[网络] Agent 注册: {agent_card.name}")
        print(f"        技能: {[s.name for s in agent_card.skills]}")

    def find_agent(self, skill_id: str) -> Optional[AgentCard]:
        """根据技能 ID 找到合适的 Agent"""
        for agent in self.agents.values():
            for skill in agent.skills:
                if skill.id == skill_id:
                    return agent
        return None

    def create_task(self, agent_name: str, description: str) -> Task:
        """创建新任务"""
        task = Task(id="", agent_name=agent_name, description=description)
        self.tasks[task.id] = task
        print(f"[网络] 新任务创建: {task.id} -> {agent_name}")
        return task

    def route_message(self, task_id: str, sender: str, content: str):
        """路由消息到指定任务"""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.add_message(sender, content)
            print(f"[网络] 消息已路由到任务 {task_id}: {sender} -> {content[:50]}...")
