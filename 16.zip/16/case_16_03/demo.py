from a2a_network import AgentNetwork
from agents import TaskDispatcherAgent, WeatherQueryAgent


def main():
    # 初始化 A2A 网络
    network = AgentNetwork()

    # 启动两个 Agent
    dispatcher = TaskDispatcherAgent(network)
    weather_agent = WeatherQueryAgent(network)

    print("\n" + "=" * 50)
    print("A2A 网络初始化完成！")
    print("=" * 50)

    # 模拟用户请求
    requests = [
        "我想查一下北京的天气",
        "帮我搜索一下今天的科技新闻",
        "给我发送一封邮件给老板",
    ]

    for req in requests:
        result = dispatcher.handle_request(req)
        print(f"分发结果: {result}")


if __name__ == "__main__":
    main()
